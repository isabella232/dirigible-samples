require("./animation.js");
require("./people.js").open();
require("./tray.js");

tabris.create("Drawer").append(tabris.create("PageSelector"));
